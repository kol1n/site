async function checkAuth() {
    try {
        const r = await fetch('/api/profile');
        if (r.status === 401) {
        window.location.href = '/login/';
        } else {
        const data = await r.json();
        }
    } catch (err) {
        console.error(err);
    }
}

async function logoutAuth() {
    try {
        const r = await fetch('/api/logout', { method: 'POST' });
        const data = await r.json();
        if (data.success) {
            window.location.href = '/index.html';
        }
    } catch (err) {
        console.error(err);
    }
}

checkAuth();
document.addEventListener("DOMContentLoaded", () => {
    const btn = document.getElementById('logout-btn');
    if (btn) {
        btn.addEventListener('click', async (e) => {
            e.preventDefault();
            await logoutAuth();
        });
    }
});
