async function loadUsers() {
    try {
        const res = await fetch('/V1/data/users.json');
        if (!res.ok) throw new Error('Cannot fetch users');
        const users = await res.json();

        const container = document.getElementById('contacts-list');
        if (!container) return;

        const userIds = [];

        Object.values(users).forEach(user => {
            const userDiv = document.createElement('div');
            userDiv.className = 'user-card';
            userDiv.innerHTML = `
                <img src="${user.avatar}" alt="${user.name}" style="width:50px;height:50px;border-radius:50%;">
                <span>${user.name}</span>
            `;
            userDiv.addEventListener('click', () => {
                window.location.href = `../dashboard?user=${user.id}`;
            });
            container.appendChild(userDiv);

            userIds.push(user.id);
        });

        // Зберігаємо у localStorage
        localStorage.setItem('userIds', JSON.stringify(userIds));

        // Відправляємо айді на сервер
        const encodedData = encodeURIComponent(JSON.stringify(userIds));
        await fetch(`/api/writefile/${encodedData}`, {
            method: 'GET'
        });

        console.log('User IDs successfully sent to /api/writefile');
    } catch (err) {
        console.error(err);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    loadUsers();
});
