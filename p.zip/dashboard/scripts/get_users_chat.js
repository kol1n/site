async function loadCache() {
    try {
        const res = await fetch('/api/readfile');
        if (!res.ok) throw new Error('Cannot fetch cache');

        const data = await res.json();
        console.log('Cache content:', data);
        return data;
    } catch (err) {
        console.error(err);
        return [];
    }
}

async function getUserChat() {
    const params = new URLSearchParams(window.location.search);
    const userId = params.get('user');
    if (!userId) return;

    try {
        const res = await fetch(`/api/chats/${userId}`);
        if (!res.ok) throw new Error('Cannot fetch user chat');

        const data = await res.json();
        const chatContainer = document.getElementById('chat-container');
        if (!chatContainer) return;

        chatContainer.innerHTML = ''; 

        Object.values(data).forEach(msg => {
            const msgDiv = document.createElement('div');
            msgDiv.className = msg.sender === 'me' ? 'my-message' : 'user-message';
            msgDiv.textContent = `[${new Date(msg.timestamp).toLocaleTimeString()}] ${msg.sender}: ${msg.text}`;
            chatContainer.appendChild(msgDiv);
        });

    } catch (err) {
        console.error(err);
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    await loadCache(); 
    await getUserChat(); 
});
