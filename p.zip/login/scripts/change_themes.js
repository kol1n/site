
async function changeTheme() {
  const themeToggle = document.getElementById("theme-toggle");
  const themeLink = document.getElementById("theme-link");

  if (localStorage.getItem("theme") === "black") {
    themeLink.href = "/login/styles/black.css";
    themeToggle.textContent = "☀️";
  } else {
    themeLink.href = "/login/styles/white.css";
    themeToggle.textContent = "🌙";
  }

  themeToggle.addEventListener("click", () => {
    if (themeLink.getAttribute("href").includes("white.css")) {
      themeLink.href = "/login/styles/black.css";
      themeToggle.textContent = "☀️";
      localStorage.setItem("theme", "black");
    } else {
      themeLink.href = "/login/styles/white.css";
      themeToggle.textContent = "🌙";
      localStorage.setItem("theme", "white");
    }
  });
};

document.addEventListener("DOMContentLoaded", () => {
  changeTheme();
});
