// site/login/V1/login_api.js
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const crypto = require('crypto');
const fs = require('fs');

const app = express();
const PORT = 5050;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, '..')));

const sessions = new Map();

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (username === 'admin' && password === '312') {
    const sessionId = crypto.randomBytes(32).toString('hex');
    sessions.set(sessionId, { username, createdAt: Date.now() });
    res.cookie('session', sessionId, {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 1.5 * 30 * 24 * 60 * 60 * 1000,
    });
    return res.json({ success: true, message: 'Вхід успішний', redirect: '/dashboard' });
  }
  return res.status(401).json({ success: false, message: 'Невірний логін/пароль' });
});

function requireAuth(req, res, next) {
  const sessionId = req.cookies.session;
  if (!sessionId || !sessions.has(sessionId)) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  req.user = sessions.get(sessionId);
  next();
}

app.get('/dashboard', (req, res) => {
  const sessionId = req.cookies.session;
  if (!sessionId || !sessions.has(sessionId)) {
    return res.redirect('/index.html');
  }
  const session = sessions.get(sessionId);
  res.sendFile(path.join(__dirname, '..', 'dashboard.html'));
});

app.get('/api/profile', requireAuth, (req, res) => {
  res.json({ username: req.user.username, createdAt: req.user.createdAt });
});

app.post('/api/logout', requireAuth, (req, res) => {
  const sessionId = req.cookies.session;
  sessions.delete(sessionId);
  res.clearCookie('session', { httpOnly: true, sameSite: 'lax' });
  res.json({ success: true });
});

app.get('/api/users', requireAuth, (req, res) => {
  fs.readFile(path.join(__dirname, '/data/users.json'), 'utf8', (err, data) => {
    if (err) return res.status(500).json({ error: 'Cannot read users.json' });
    const users = JSON.parse(data);
    res.json(users);
  });
});

app.get('/api/users/:id', requireAuth, (req, res) => {
  fs.readFile(path.join(__dirname, '/data/users.json'), 'utf8', (err, data) => {
    if (err) return res.status(500).json({ error: 'Cannot read users.json' });
    const users = JSON.parse(data);
    const user = Object.values(users).find(u => u.id === req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  });
});

app.get('/api/chats/:userId', requireAuth, (req, res) => {
  fs.readFile(path.join(__dirname, '/data/chats.json'), 'utf8', (err, data) => {
    if (err) return res.status(500).json({ error: 'Cannot read chats.json' });
    const chats = JSON.parse(data);
    const userChats = chats[req.params.userId] || [];
    res.json(userChats);
})});

app.get('/api/chats/:userId/createmessage/:message', requireAuth, (req, res) => {
  const userId = req.params.userId;
  const message = req.params.message;

  const filePath = path.join(__dirname, '/data/chats.json');

  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) return res.status(500).json({ error: 'Cannot read chats.json' });

    let chats = {};
    try {
      chats = JSON.parse(data);
    } catch (e) {
      return res.status(500).json({ error: 'Invalid JSON in chats.json' });
    }

    if (!chats[userId]) chats[userId] = [];

    const newMessage = {
      id: crypto.randomBytes(16).toString('hex'),
      text: message,
      timestamp: new Date().toISOString(),
      sender: req.user.username,
    };

    chats[userId].push(newMessage);

    fs.writeFile(filePath, JSON.stringify(chats, null, 2), 'utf8', (err) => {
      if (err) return res.status(500).json({ error: 'Cannot write chats.json' });
      res.json({ success: true, message: newMessage });
    });
  });
});

app.get('/api/writefile/:data', requireAuth, (req, res) => {
  const sampleData = req.params.data;

  fs.writeFile(
    path.join(__dirname, 'cache', 'cache.json'),
    sampleData,
    'utf8',
    (err) => {
      if (err) return res.status(500).json({ error: 'Cannot write' });
      res.json({ success: true, written: sampleData });
    }
  );
});

app.get('/api/readfile', requireAuth, (req, res) => {
  fs.readFile(
    path.join(__dirname, 'cache', 'cache.json'),
    'utf8',
    (err, data) => {
      if (err) return res.status(500).json({ error: 'Cannot read' });
      res.json({ success: true, data });
    }
  );
});

app.listen(PORT, () => console.log(`Server on http://localhost:${PORT}`));
